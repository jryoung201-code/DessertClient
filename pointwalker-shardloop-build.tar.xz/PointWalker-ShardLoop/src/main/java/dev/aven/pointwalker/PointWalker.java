package dev.aven.pointwalker;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec3d;
import java.nio.file.*;
import java.util.*;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.*;

public class PointWalker implements ClientModInitializer {
    private static PointWalker instance;
    private boolean forward, jumping;
    public static boolean isFollowing() {
        var c = MinecraftClient.getInstance();
        return instance != null && instance.running && c.player != null && c.world != null && c.player.isAlive();
    }
    public static PlayerInput movementInput() {
        if (!isFollowing() || !instance.held) return null;
        return new PlayerInput(instance.forward, false, false, false, instance.jumping, instance.data.action.equals("sneak"), instance.data.action.equals("sprint"));
    }
    record Point(double x, double y, double z, String dimension) {}
    static class Data { List<Point> points = new ArrayList<>(); String action = "walk"; boolean loop = false; }
    private final Path file = FabricLoader.getInstance().getConfigDir().resolve("pointwalker.json");
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private Data data = new Data();
    private boolean running, held;
    private List<Point> automationRoute = null;
    private boolean automationLoop;
    private int index, stuck;
    private double best = Double.POSITIVE_INFINITY;
    private void say(String s) { var c=MinecraftClient.getInstance(); if(c.player!=null)c.player.sendMessage(Text.literal("[PointWalker] " + s),false); }
    private void save() { try { Files.createDirectories(file.getParent()); Path tmp=file.resolveSibling("pointwalker.json.tmp"); Files.writeString(tmp,gson.toJson(data)); Files.move(tmp,file,StandardCopyOption.REPLACE_EXISTING); } catch(Exception e){say("Could not save points: "+e.getMessage());} }
    public void onInitializeClient() {
        instance = this;
        try { if(Files.exists(file)) { Data loaded=gson.fromJson(Files.readString(file),Data.class); if(loaded!=null && loaded.points!=null && loaded.points.stream().allMatch(p->p!=null && Double.isFinite(p.x) && Double.isFinite(p.y) && Double.isFinite(p.z))) data=loaded; } } catch(Exception ignored) {}
        if(!List.of("walk","sprint","sneak").contains(data.action))data.action="walk";
        ClientCommandRegistrationCallback.EVENT.register((d,a)-> {
            d.register(literal("point")
                .then(literal("set").executes(c->add("~ ~ ~")).then(argument("coordinates",StringArgumentType.greedyString()).executes(c->add(StringArgumentType.getString(c,"coordinates")))))
                .then(literal("remove").then(argument("points",StringArgumentType.greedyString()).executes(c->remove(StringArgumentType.getString(c,"points")))))
                .then(literal("list").executes(c->{if(data.points.isEmpty())say("No points saved."); for(int i=0;i<data.points.size();i++){var p=data.points.get(i);say((i+1)+": "+p.x+" "+p.y+" "+p.z+" ("+p.dimension+")");}return 1;}))
                .then(literal("loop")
                    .executes(c->{say("Loop: "+(data.loop ? "on" : "off"));return 1;})
                    .then(literal("on").executes(c->{data.loop=true;save();say("Loop enabled.");return 1;}))
                    .then(literal("off").executes(c->{data.loop=false;save();say("Loop disabled. The current pass will finish.");return 1;})))
                .then(literal("start").executes(c->{automationPause();if(data.points.isEmpty()){say("Set a point first.");return 0;}index=0;running=true;say("Following "+data.points.size()+" points ("+data.action+").");return 1;}))
                .then(literal("stop").executes(c->{stop();say("Stopped.");return 1;})));
            var action=literal("action");
            for(String mode:List.of("sprint","sneak","walk"))action.then(literal(mode).executes(c->{data.action=mode;save();say("Movement: "+mode);return 1;}));
            d.register(action);
        });
        ShardLoopController.init(this);
        ClientTickEvents.START_CLIENT_TICK.register(this::tick);
    }
    private int add(String raw) {
        var c=MinecraftClient.getInstance();if(c.player==null||c.world==null)return 0;
        try {
            String[] args=raw.replace('(',' ').replace(')',' ').trim().split("\\s+");if(args.length!=3)throw new IllegalArgumentException();
            double x=coord(args[0],c.player.getX()),y=coord(args[1],c.player.getY()),z=coord(args[2],c.player.getZ());
            if(Math.abs(x)>30000000||Math.abs(z)>30000000||Math.abs(y)>30000000)throw new IllegalArgumentException();
            stop();data.points.add(new Point(x,y,z,c.world.getRegistryKey().getValue().toString()));save();say("Point "+data.points.size()+" set at "+x+" "+y+" "+z);return 1;
        }catch(Exception e){say("Use /point set <x> <y> <z>, e.g. /point set ~ ~ ~10");return 0;}
    }
    private double coord(String s,double base){double v=s.startsWith("~")?base+(s.length()==1?0:Double.parseDouble(s.substring(1))):Double.parseDouble(s);if(!Double.isFinite(v))throw new IllegalArgumentException();return v;}
    private int remove(String raw) {
        if(raw.equalsIgnoreCase("all")){stop();data.points.clear();save();say("Removed all points.");return 1;}
        try{Set<Integer> ids=new TreeSet<>(Comparator.reverseOrder());for(String s:raw.trim().split("[ ,]+")){int id=Integer.parseInt(s);if(id<1||id>data.points.size())throw new IllegalArgumentException();ids.add(id-1);}stop();for(int id:ids)data.points.remove(id);save();say("Removed "+ids.size()+" points. Remaining points renumbered.");return 1;}catch(Exception e){say("Use /point remove <number(s)> or /point remove all");return 0;}
    }
    private void release(MinecraftClient c){if(!held)return;c.options.forwardKey.setPressed(false);c.options.sprintKey.setPressed(false);c.options.sneakKey.setPressed(false);c.options.jumpKey.setPressed(false);if(c.player!=null)c.player.setSprinting(false);held=false;}
    private void stop(){running=false;release(MinecraftClient.getInstance());stuck=0;best=Double.POSITIVE_INFINITY;}
    public void automationMove(List<Vec3d> targets, boolean repeat) {
        stop();
        var client = MinecraftClient.getInstance();
        if (client.world == null || targets == null || targets.isEmpty()) return;
        String dimension = client.world.getRegistryKey().getValue().toString();
        automationRoute = targets.stream().map(p -> new Point(p.x, p.y, p.z, dimension)).toList();
        automationLoop = repeat;
        index = 0;
        running = true;
    }
    public void automationPause() {
        stop();
        automationRoute = null;
        automationLoop = false;
    }
    public boolean automationIsMoving() { return automationRoute != null && running; }
    private void tick(MinecraftClient c){
        if(!running)return;
        if(c.player==null||c.world==null||!c.player.isAlive()){stop();return;}
        List<Point> route = automationRoute != null ? automationRoute : data.points;
        if (route.isEmpty() || index < 0 || index >= route.size()) { stop(); return; }
        Point p=route.get(index);
        if(!c.world.getRegistryKey().getValue().toString().equals(p.dimension)){stop();say("Stopped: point is in another dimension.");return;}
        double dx=p.x-c.player.getX(), dz=p.z-c.player.getZ(), dy=p.y-c.player.getY();double distance=Math.hypot(dx,dz);
        if(distance<0.6&&Math.abs(dy)<1.5){release(c);index++;best=Double.POSITIVE_INFINITY;stuck=0;if(index>=route.size()){if(automationRoute != null ? automationLoop : data.loop){index=0;}else{stop();if(automationRoute == null) say("Route complete.");}}return;}
        if(distance+Math.abs(dy)<best-0.1){best=distance+Math.abs(dy);stuck=0;}else if(++stuck>100){stop();say("Stopped: unable to reach point "+(index+1)+".");return;}
        if(distance>0.15)c.player.setYaw((float)Math.toDegrees(Math.atan2(-dx,dz)));
        forward=distance>=0.3;
        jumping=c.player.isOnGround() && (c.player.horizontalCollision || dy>0.6);
        held=true;c.options.forwardKey.setPressed(forward);c.options.sneakKey.setPressed(data.action.equals("sneak"));c.options.sprintKey.setPressed(data.action.equals("sprint"));c.player.setSprinting(data.action.equals("sprint"));
        c.options.jumpKey.setPressed(jumping);
    }
}
