package dev.aven.pointwalker;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.*;

/** Client-only controller; the server decides whether a purchase and spawner use succeeds. */
public final class ShardLoopController {
    private enum Stage { OFF, CIRCLE, SHOP_OPENING, SHOP_BUYING, ITEM_WAIT, FIND_SPAWNER, APPROACH, USE_SPAWNER, VERIFY }
    private static final Pattern BALANCE = Pattern.compile("(?i)\\bshards?\\s*[:：=-]?\\s*\\$?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?\\s*[kmbt]?)\\b");
    private static final String SHOP_TITLE = "shard shop";
    private static final String PURCHASE_ITEM = "skeleton spawner";
    private static final int PRICE = 900;
    private static final int SEARCH_RADIUS = 20;
    private static ShardLoopController INSTANCE;

    private final PointWalker walker;
    private Stage stage = Stage.OFF;
    private Vec3d center;
    private String dimension;
    private int radius = 5;
    private boolean trail = true;
    private int ticks;
    private int cooldown;
    private int balance = -1;
    private int lastBalanceTick = -100000;
    private int worldTick;
    private int ownedBefore;
    private int useBefore;
    private int oldHotbarSlot = -1;
    private BlockPos chosenSpawner;
    private List<Vec3d> circle = List.of();
    private Vec3d approachTarget;

    private ShardLoopController(PointWalker walker) { this.walker = walker; }

    public static void init(PointWalker walker) {
        INSTANCE = new ShardLoopController(walker);
        ClientTickEvents.END_CLIENT_TICK.register(INSTANCE::tick);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registry) -> {
            dispatcher.register(literal("shardloop")
                .then(literal("center").executes(ctx -> INSTANCE.setCenter()))
                .then(literal("radius").then(argument("blocks", IntegerArgumentType.integer(2, 20))
                    .executes(ctx -> INSTANCE.setRadius(IntegerArgumentType.getInteger(ctx, "blocks")))))
                .then(literal("start").executes(ctx -> INSTANCE.start()))
                .then(literal("stop").executes(ctx -> INSTANCE.stop("Stopped.")))
                .then(literal("status").executes(ctx -> INSTANCE.status()))
                .then(literal("trail")
                    .then(literal("on").executes(ctx -> INSTANCE.setTrail(true)))
                    .then(literal("off").executes(ctx -> INSTANCE.setTrail(false))));
        });
    }

    /** Called by client HUD mixins. We only trust text that explicitly labels a shard count. */
    public static void observeText(Text text) {
        if (INSTANCE != null && text != null) INSTANCE.parseShards(text.getString());
    }
    private void parseShards(String raw) {
        Matcher match = BALANCE.matcher(raw.replace('§', ' '));
        if (!match.find()) return;
        String number = match.group(1).replace(",", "").replace(" ", "").toLowerCase(Locale.ROOT);
        try {
            double factor = 1.0;
            if (number.endsWith("k")) { factor = 1_000; number = number.substring(0, number.length() - 1); }
            else if (number.endsWith("m")) { factor = 1_000_000; number = number.substring(0, number.length() - 1); }
            else if (number.endsWith("b")) { factor = 1_000_000_000; number = number.substring(0, number.length() - 1); }
            else if (number.endsWith("t")) { factor = 1_000_000_000_000.0; number = number.substring(0, number.length() - 1); }
            double n = Double.parseDouble(number) * factor;
            if (n >= 0 && n <= Integer.MAX_VALUE) { balance = (int) n; lastBalanceTick = worldTick; }
        } catch (NumberFormatException ignored) {}
    }

    private void readScoreboard(MinecraftClient c) {
        if (c.world == null) return;
        var board = c.world.getScoreboard();
        for (ScoreboardObjective objective : board.getObjectives()) {
            for (ScoreboardEntry entry : board.getScoreboardEntries(objective)) {
                String label = (entry.display() != null ? entry.display().getString() : entry.owner());
                Matcher match = BALANCE.matcher(label);
                if (match.find()) {
                    parseShards(label);
                } else if (label.toLowerCase(Locale.ROOT).trim().matches(".*\\bshards?\\s*[:：]?\\s*")) {
                    // Some servers store currency as the numeric scoreboard score.
                    if (entry.value() >= 0) { balance = entry.value(); lastBalanceTick = worldTick; }
                }
            }
        }
    }

    private void say(String message) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player != null) c.player.sendMessage(Text.literal("[ShardLoop] " + message), false);
    }
    private int setCenter() {
        var c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null) return 0;
        center = c.player.getPos();
        dimension = c.world.getRegistryKey().getValue().toString();
        say("Circle center set at " + center.toString() + ".");
        return 1;
    }
    private int setRadius(int value) {
        radius = value;
        say("Radius set to " + radius + " blocks. Restart to update the route.");
        return 1;
    }
    private int setTrail(boolean value) {
        trail = value;
        say("Path preview " + (value ? "enabled" : "disabled") + ".");
        return 1;
    }
    private int status() {
        say("State: " + stage + "; radius=" + radius + "; shards=" + (balance >= 0 && worldTick - lastBalanceTick < 200 ? balance : "not detected") + "; trail=" + trail);
        if (stage != Stage.OFF && center != null) say("Center: " + center + "; target spawner: " + (chosenSpawner == null ? "none" : chosenSpawner));
        return 1;
    }
    private int start() {
        var c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null || !c.player.isAlive()) return 0;
        if (center == null || !c.world.getRegistryKey().getValue().toString().equals(dimension)) {
            center = c.player.getPos();
            dimension = c.world.getRegistryKey().getValue().toString();
        }
        stopInternal();
        circle = new ArrayList<>();
        for (int i = 0; i < 16; i++) {
            double theta = (2 * Math.PI * i) / 16;
            circle.add(new Vec3d(center.x + Math.cos(theta) * radius, center.y, center.z + Math.sin(theta) * radius));
        }
        cooldown = 0;
        stage = Stage.CIRCLE;
        walker.automationMove(circle, true);
        say("Walking a " + radius + "-block-radius circle. At " + PRICE + " shards: buy a Skeleton Spawner, then use it on the nearest loaded spawner.");
        return 1;
    }
    private int stop(String why) { stopInternal(); say(why); return 1; }
    private void stopInternal() {
        walker.automationPause();
        stage = Stage.OFF;
        chosenSpawner = null;
        approachTarget = null;
        oldHotbarSlot = -1;
        ticks = 0;
    }
    private void resumeCircle(String message, int delayTicks) {
        if (message != null) say(message);
        walker.automationPause();
        stage = Stage.CIRCLE;
        cooldown = delayTicks;
        ticks = 0;
        chosenSpawner = null;
        approachTarget = null;
        oldHotbarSlot = -1;
        walker.automationMove(circle, true);
    }

    private void tick(MinecraftClient c) {
        worldTick++;
        if (c.world == null || c.player == null || !c.player.isAlive()) {
            if (stage != Stage.OFF) stopInternal();
            balance = -1;
            return;
        }
        if (worldTick % 20 == 0) readScoreboard(c);
        if (stage == Stage.OFF) return;
        if (!c.world.getRegistryKey().getValue().toString().equals(dimension)) {
            stop("Dimension changed; stopped to avoid travelling to the wrong route.");
            return;
        }
        ticks++;
        if (cooldown > 0) cooldown--;
        if (trail && worldTick % 6 == 0) showTrail(c);
        switch (stage) {
            case CIRCLE -> {
                if (!walker.automationIsMoving()) walker.automationMove(circle, true);
                if (cooldown == 0 && balance >= PRICE && worldTick - lastBalanceTick < 200) {
                    walker.automationPause();
                    ownedBefore = countSpawnerItems(c);
                    stage = Stage.SHOP_OPENING;
                    ticks = 0;
                    c.player.networkHandler.sendChatCommand("shardShop");
                    say("Detected " + balance + " shards. Opening /shardShop.");
                }
            }
            case SHOP_OPENING -> {
                if (c.currentScreen instanceof HandledScreen<?> screen) {
                    if (screen.getTitle().getString().toLowerCase(Locale.ROOT).contains(SHOP_TITLE)) {
                        stage = Stage.SHOP_BUYING; ticks = 0;
                    }
                }
                if (ticks > 120) resumeCircle("Shard Shop did not open. Trying again later.", 400);
            }
            case SHOP_BUYING -> {
                if (!(c.currentScreen instanceof HandledScreen<?> screen)
                    || !screen.getTitle().getString().toLowerCase(Locale.ROOT).contains(SHOP_TITLE)) {
                    if (ticks > 40) resumeCircle("Shard Shop closed before the Skeleton Spawner could be found.", 400);
                    break;
                }
                if (ticks < 4) break;
                Slot match = null;
                for (Slot slot : c.player.currentScreenHandler.slots) {
                    ItemStack stack = slot.getStack();
                    if (!stack.isEmpty() && stack.getName().getString().toLowerCase(Locale.ROOT).contains(PURCHASE_ITEM)) {
                        match = slot; break;
                    }
                }
                if (match != null) {
                    c.interactionManager.clickSlot(c.player.currentScreenHandler.syncId, match.id, 0, SlotActionType.PICKUP, c.player);
                    stage = Stage.ITEM_WAIT;
                    ticks = 0;
                    say("Clicked Skeleton Spawner once; waiting for the server to deliver it.");
                } else if (ticks > 80) {
                    resumeCircle("No Skeleton Spawner item was found in the shard shop GUI.", 400);
                }
            }
            case ITEM_WAIT -> {
                if (countSpawnerItems(c) > ownedBefore) {
                    if (c.currentScreen instanceof HandledScreen<?>) c.player.closeHandledScreen();
                    stage = Stage.FIND_SPAWNER;
                    ticks = 0;
                    say("Spawner received. Finding the nearest loaded spawner.");
                } else if (ticks > 120) {
                    if (c.currentScreen instanceof HandledScreen<?>) c.player.closeHandledScreen();
                    resumeCircle("Couldn't confirm purchase or delivery; won't double-click the shop item.", 400);
                }
            }
            case FIND_SPAWNER -> {
                chosenSpawner = nearestSpawner(c);
                if (chosenSpawner == null) {
                    resumeCircle("No spawner detected in loaded blocks within " + SEARCH_RADIUS + " blocks. Keeping the item.", 200);
                } else {
                    approachTarget = findStandingLocation(c, chosenSpawner);
                    if (approachTarget == null) {
                        resumeCircle("Nearest spawner has no obvious safe adjacent standing tile; keeping item.", 200);
                    } else {
                        walker.automationMove(List.of(approachTarget), false);
                        stage = Stage.APPROACH;
                        ticks = 0;
                        say("Approaching spawner at " + chosenSpawner.toShortString() + ".");
                    }
                }
            }
            case APPROACH -> {
                double horizontal = Math.hypot(c.player.getX() - approachTarget.x, c.player.getZ() - approachTarget.z);
                if (horizontal < 0.9 && Math.abs(c.player.getY() - approachTarget.y) < 1.5) {
                    walker.automationPause();
                    stage = Stage.USE_SPAWNER;
                    ticks = 0;
                } else if ((ticks > 30 && !walker.automationIsMoving()) || ticks > 450) {
                    resumeCircle("Unable to walk to spawner; keeping purchased item.", 200);
                }
            }
            case USE_SPAWNER -> {
                if (ticks < 4) break;
                int slot = findSpawnerItem(c);
                if (slot < 0) {
                    resumeCircle("Purchased Skeleton Spawner is no longer in inventory.", 200);
                    break;
                }
                PlayerInventory inv = c.player.getInventory();
                if (slot >= 9 && slot < 36) {
                    int hotbar = pickHotbarSlot(c);
                    c.interactionManager.clickSlot(c.player.playerScreenHandler.syncId, slot, hotbar, SlotActionType.SWAP, c.player);
                    stage = Stage.USE_SPAWNER;
                    ticks = -6; // give inventory updates time before selecting
                    break;
                }
                if (slot > 8) {
                    resumeCircle("Spawner is in an unsupported inventory slot; keeping item.", 200);
                    break;
                }
                if (c.world.getBlockState(chosenSpawner).getBlock() != Blocks.SPAWNER) {
                    resumeCircle("Target block changed; keeping item.", 200);
                    break;
                }
                if (c.player.getPos().distanceTo(chosenSpawner.toCenterPos()) > 5.0) {
                    resumeCircle("Spawner is out of interaction reach; keeping item.", 200);
                    break;
                }
                if (oldHotbarSlot < 0) oldHotbarSlot = inv.getSelectedSlot();
                inv.setSelectedSlot(slot);
                useBefore = inv.getStack(slot).getCount();
                Vec3d from = c.player.getPos().subtract(chosenSpawner.toCenterPos());
                Direction face = Math.abs(from.x) > Math.abs(from.z) ? (from.x > 0 ? Direction.EAST : Direction.WEST)
                    : (from.z > 0 ? Direction.SOUTH : Direction.NORTH);
                Vec3d hit = chosenSpawner.toCenterPos().add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
                c.interactionManager.interactBlock(c.player, Hand.MAIN_HAND, new BlockHitResult(hit, face, chosenSpawner, false));
                c.player.swingHand(Hand.MAIN_HAND);
                stage = Stage.VERIFY;
                ticks = 0;
            }
            case VERIFY -> {
                if (ticks < 12) break;
                if (oldHotbarSlot >= 0) c.player.getInventory().setSelectedSlot(oldHotbarSlot);
                if (countSpawnerItems(c) < ownedBefore + 1) {
                    resumeCircle("Spawner interaction sent and item appears consumed. Back to walking.", 200);
                } else {
                    resumeCircle("Right-click sent but server didn't confirm item was consumed. Check the target spawner.", 400);
                }
            }
            default -> {}
        }
    }

    private int countSpawnerItems(MinecraftClient c) {
        int total = 0;
        for (int i = 0; i < c.player.getInventory().size(); i++) {
            ItemStack st = c.player.getInventory().getStack(i);
            if (isSkeletonSpawner(st)) total += st.getCount();
        }
        return total;
    }
    private int findSpawnerItem(MinecraftClient c) {
        for (int i = 0; i < c.player.getInventory().size(); i++) {
            if (isSkeletonSpawner(c.player.getInventory().getStack(i))) return i;
        }
        return -1;
    }
    private static boolean isSkeletonSpawner(ItemStack stack) {
        return !stack.isEmpty() && stack.getName().getString().toLowerCase(Locale.ROOT).contains(PURCHASE_ITEM);
    }
    private int pickHotbarSlot(MinecraftClient c) {
        var inventory = c.player.getInventory();
        for (int hotbar = 0; hotbar < 9; hotbar++) if (inventory.getStack(hotbar).isEmpty()) return hotbar;
        return inventory.getSelectedSlot();
    }
    private BlockPos nearestSpawner(MinecraftClient c) {
        BlockPos origin = c.player.getBlockPos();
        BlockPos nearest = null;
        double best = Double.POSITIVE_INFINITY;
        for (BlockPos p : BlockPos.iterateOutwards(origin, SEARCH_RADIUS, 5, SEARCH_RADIUS)) {
            if (c.world.getBlockState(p).getBlock() == Blocks.SPAWNER) {
                double d = p.getSquaredDistance(origin);
                if (d < best) { best = d; nearest = p.toImmutable(); }
            }
        }
        return nearest;
    }
    private Vec3d findStandingLocation(MinecraftClient c, BlockPos spawner) {
        Vec3d best = null;
        double bestDist = Double.POSITIVE_INFINITY;
        for (Direction d : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST}) {
            for (int distance = 1; distance <= 2; distance++) {
                BlockPos stand = spawner.offset(d, distance);
                if (!c.world.getBlockState(stand).isAir() || !c.world.getBlockState(stand.up()).isAir()) continue;
                if (!c.world.getBlockState(stand.down()).isSolidBlock(c.world, stand.down())) continue;
                Vec3d pos = new Vec3d(stand.getX() + 0.5, stand.getY(), stand.getZ() + 0.5);
                double fromPlayer = c.player.getPos().squaredDistanceTo(pos);
                if (fromPlayer < bestDist) { best = pos; bestDist = fromPlayer; }
            }
        }
        return best;
    }
    private void showTrail(MinecraftClient c) {
        List<Vec3d> route;
        if (stage == Stage.APPROACH && approachTarget != null) route = List.of(c.player.getPos(), approachTarget);
        else if (stage == Stage.CIRCLE) route = circle;
        else return;
        if (route.size() < 2) return;
        // Short-lived client-only particles: no modifications to the server or world.
        for (int i = 0; i < route.size(); i++) {
            Vec3d a = route.get(i);
            Vec3d b = route.get((i + 1) % route.size());
            if (stage == Stage.APPROACH && i + 1 >= route.size()) break;
            if (a.squaredDistanceTo(c.player.getPos()) > 32 * 32) continue;
            for (int j = 0; j < 2; j++) {
                Vec3d p = a.lerp(b, (j + 0.5) / 2.0);
                c.world.addParticleClient(ParticleTypes.END_ROD, p.x, p.y + 0.22, p.z, 0, 0.006, 0);
            }
        }
    }
}
