package dev.aven.pointwalker.mixin;

import dev.aven.pointwalker.PointWalker;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    @Inject(method = "tick", at = @At("TAIL"))
    private void pointwalker$applyMovement(CallbackInfo ci) {
        PlayerInput desired = PointWalker.movementInput();
        if (desired == null) return;
        playerInput = desired;
        movementVector = new Vec2f(0.0F, desired.forward() ? 1.0F : 0.0F);
    }
}
